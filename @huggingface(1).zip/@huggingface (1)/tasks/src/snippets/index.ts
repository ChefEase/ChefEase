import * as inputs from "./inputs";
import * as curl from "./curl";
import * as python from "./python";
import * as js from "./js";

export { inputs, curl, python, js };
