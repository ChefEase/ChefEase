## Use Cases

You can contribute this area with common use cases of the task!

## Task Variants

This place can be filled with variants of this task if there's any.

## Inference

This section should have useful information about how to pull a model from Hugging Face Hub that is a part of a library specialized in a task and use it.

## Useful Resources

In this area, you can insert useful resources about how to train or use a model for this task.
