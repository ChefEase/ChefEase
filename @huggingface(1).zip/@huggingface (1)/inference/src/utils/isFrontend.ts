import { isBackend } from "./isBackend";

export const isFrontend = !isBackend;
